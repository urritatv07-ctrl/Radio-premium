package com.radiopremium.app

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Gold = Color(0xFFD4AF37)
private val SoftWhite = Color(0xFFF5F1E6)

data class Station(val name: String, val country: String, val url: String)

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, RadioPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, mainExecutor)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Gold, background = Black, surface = Panel,
                onPrimary = Black, onBackground = SoftWhite, onSurface = SoftWhite
            )) {
                RadioPremiumScreen(controller)
            }
        }
    }

    override fun onDestroy() {
        controller?.release()
        super.onDestroy()
    }
}

@Composable
fun RadioPremiumScreen(controller: MediaController?) {
    var stations by remember { mutableStateOf<List<Station>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<Station?>(null) }
    var query by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var onlyFavorites by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        try {
            stations = loadStations()
            if (stations.isEmpty()) error = "No se encontraron emisoras. Intenta nuevamente."
        } catch (e: Exception) {
            error = "No se pudo cargar el catálogo. Revisa tu conexión."
        } finally { loading = false }
    }

    val visible = stations.filter {
        (it.name.contains(query, true) || it.country.contains(query, true)) &&
        (!onlyFavorites || favorites.contains(it.url))
    }

    Column(Modifier.fillMaxSize().background(Black).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("RADIO", color = SoftWhite, fontSize = 14.sp, letterSpacing = 5.sp, fontWeight = FontWeight.Bold)
        Text("PREMIUM", color = Gold, fontSize = 34.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Black)
        Text("EL MUNDO DE LA RADIO EN TUS MANOS", color = Color.LightGray, fontSize = 10.sp, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar emisora o país…", color = Color.Gray) },
            singleLine = true, shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Gold, unfocusedBorderColor = Color.DarkGray,
                focusedTextColor = SoftWhite, unfocusedTextColor = SoftWhite
            )
        )
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(if (onlyFavorites) "MIS FAVORITAS" else "EMISORAS DEL MUNDO", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            TextButton(onClick = { onlyFavorites = !onlyFavorites }) {
                Text(if (onlyFavorites) "Ver todas" else "Favoritas", color = Gold)
            }
        }
        when {
            loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
            error != null && stations.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(error!!, color = SoftWhite) }
            visible.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("No hay resultados.", color = Color.LightGray) }
            else -> LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(visible) { station ->
                    StationRow(station, favorites.contains(station.url), onFavorite = {
                        favorites = if (favorites.contains(station.url)) favorites - station.url else favorites + station.url
                    }, onPlay = {
                        selected = station
                        controller?.setMediaItem(MediaItem.Builder().setUri(station.url).setMediaId(station.url)
                            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(station.name).setArtist(station.country).build()).build())
                        controller?.prepare()
                        controller?.play()
                    })
                }
            }
        }
        selected?.let { current ->
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("REPRODUCIENDO AHORA", color = Gold, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Text(current.name, color = SoftWhite, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
                Text(current.country, color = Color.LightGray, fontSize = 12.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    IconButton(onClick = { if (controller?.isPlaying == true) controller.pause() else controller?.play() }) {
                        Icon(if (controller?.isPlaying == true) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Gold, modifier = Modifier.size(38.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Catálogo internacional • Radio Browser", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 10.dp))
    }
}

@Composable
fun StationRow(station: Station, favorite: Boolean, onFavorite: () -> Unit, onPlay: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onPlay() }.padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).background(Color(0xFF292316), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text("♫", color = Gold, fontSize = 23.sp)
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(station.name, color = SoftWhite, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(station.country, color = Color.Gray, fontSize = 12.sp)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Gold)
        }
        Icon(Icons.Default.PlayArrow, null, tint = Gold)
    }
}

suspend fun loadStations(): List<Station> = withContext(Dispatchers.IO) {
    val client = OkHttpClient()
    val request = Request.Builder()
        .url("https://de1.api.radio-browser.info/json/stations/topvote/60")
        .header("User-Agent", "RadioPremium/1.0")
        .build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code()}")
        val body = response.body()?.string() ?: "[]"
        val array = JSONArray(body)
        (0 until array.length()).mapNotNull { i ->
            val obj = array.getJSONObject(i)
            val name = obj.optString("name").trim()
            val url = obj.optString("url_resolved").ifBlank { obj.optString("url") }
            if (name.isBlank() || url.isBlank() || !url.startsWith("http")) null
            else Station(name, obj.optString("country", "Internacional").ifBlank { "Internacional" }, url)
        }
    }
}
