# Radio Premium (Android)

Proyecto inicial de una app de radio por internet con estética negra y dorada.

## Incluye
- Catálogo internacional dinámico desde Radio Browser.
- Búsqueda por emisora o país.
- Favoritos en memoria (se reinician al cerrar la app en esta versión inicial).
- Reproducción mediante AndroidX Media3 en un servicio de reproducción.
- Interfaz oscura con acentos dorados.

## Requisitos
- Android Studio reciente.
- JDK 17.
- Android SDK 35.

## Compilar
1. Abre esta carpeta desde Android Studio.
2. Espera a que Gradle sincronice las dependencias.
3. Conecta un teléfono Android o inicia un emulador.
4. Ejecuta `app`.
5. Para generar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

El APK de depuración quedará en `app/build/outputs/apk/debug/app-debug.apk`.

## Importante
Este proyecto es una base inicial, no un APK ya compilado ni una app publicada. Las emisoras y sus URLs dependen de los directorios y de los propios operadores; algunas pueden dejar de funcionar o tener restricciones regionales. El catálogo Radio Browser es un servicio de terceros. Revisa sus condiciones y las licencias/permisos de cada emisora antes de distribuir comercialmente la aplicación.

Antes de publicar conviene completar: persistencia de favoritos, manejo de errores por emisora, icono y splash propios, política de privacidad, pruebas en distintos dispositivos y configuración de firma de lanzamiento.


## Compilar en la nube desde un teléfono
El proyecto incluye `.github/workflows/build-apk.yml` para compilar con GitHub Actions:
1. Crea un repositorio en GitHub y sube el contenido de esta carpeta (no el ZIP como único archivo).
2. Abre la pestaña Actions del repositorio.
3. Selecciona "Build Radio Premium APK" y pulsa "Run workflow".
4. Cuando termine, descarga el artefacto `Radio-Premium-APK`.
